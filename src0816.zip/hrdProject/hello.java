package hrdProject;
import java.io.*;
import java.util.*;

public class hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello world,hrd is greatman. superman.");
		
		System.out.println(new Date());
	}

}
