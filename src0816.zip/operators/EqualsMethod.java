package operators;

public class EqualsMethod {
	public static void main(String[] args) {
		Integer n1 = new Integer(47);
		Integer n2 = new Integer(47);
		System.out.println(n1.equals(n2));

	}
}

/*You must use
the special method equals( ) that exists for all objects (not primitives, which work fine with
== and !=).
*/